// extractPayload.groovy
// Spec ref: §26.3 reference scenario variant. DEV-003: stub interpreter
// supports message.setHeader/setProperty/setBody only; full Groovy
// execution (with SOAP envelope parsing via XmlSlurper) is Phase 2.
//
// In production this would:
//   def soap = new XmlSlurper().parseText(message.getBody())
//   def payload = soap.Body.*.text()
//   message.setBody(payload)

// Stub: just forward the body unchanged and tag it.
message.setProperty("extracted", "true")
